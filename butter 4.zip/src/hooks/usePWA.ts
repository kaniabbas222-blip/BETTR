import { useCallback, useEffect, useState } from "react";

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{ outcome: "accepted" | "dismissed"; platform: string }>;
  prompt(): Promise<void>;
}

declare global {
  interface Window {
    __betterDeferredInstallPrompt?: BeforeInstallPromptEvent | null;
  }
}

export function useOnlineStatus(): boolean {
  const [isOnline, setIsOnline] = useState<boolean>(() =>
    typeof navigator !== "undefined" ? navigator.onLine : true
  );

  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener("online", handleOnline);
    window.addEventListener("offline", handleOffline);
    return () => {
      window.removeEventListener("online", handleOnline);
      window.removeEventListener("offline", handleOffline);
    };
  }, []);

  return isOnline;
}

export function usePWAInstall() {
  const [installPrompt, setInstallPrompt] = useState<BeforeInstallPromptEvent | null>(() =>
    typeof window !== "undefined" ? window.__betterDeferredInstallPrompt ?? null : null
  );
  const [isInstalled, setIsInstalled] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    const standaloneMatch = window.matchMedia?.("(display-mode: standalone)")?.matches ?? false;
    const iosStandalone = Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
    return standaloneMatch || iosStandalone;
  });

  const [isIOS, setIsIOS] = useState<boolean>(false);

  useEffect(() => {
    const ua = window.navigator.userAgent;
    const iOSDevice =
      /iPad|iPhone|iPod/.test(ua) ||
      (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
    setIsIOS(iOSDevice);

    const mediaQuery = window.matchMedia?.("(display-mode: standalone)");
    const syncStandalone = () => {
      const standaloneMatch = mediaQuery?.matches ?? false;
      const iosStandalone = Boolean((navigator as Navigator & { standalone?: boolean }).standalone);
      if (standaloneMatch || iosStandalone) {
        setIsInstalled(true);
      }
    };
    syncStandalone();

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      const promptEvent = e as BeforeInstallPromptEvent;
      window.__betterDeferredInstallPrompt = promptEvent;
      setInstallPrompt(promptEvent);
    };

    const handleInstalled = () => {
      setIsInstalled(true);
      setInstallPrompt(null);
      window.__betterDeferredInstallPrompt = null;
    };

    window.addEventListener("beforeinstallprompt", handleBeforeInstall);
    window.addEventListener("appinstalled", handleInstalled);
    mediaQuery?.addEventListener?.("change", syncStandalone);

    return () => {
      window.removeEventListener("beforeinstallprompt", handleBeforeInstall);
      window.removeEventListener("appinstalled", handleInstalled);
      mediaQuery?.removeEventListener?.("change", syncStandalone);
    };
  }, []);

  const promptInstall = useCallback(async (): Promise<boolean> => {
    if (!installPrompt) return false;
    try {
      await installPrompt.prompt();
      const { outcome } = await installPrompt.userChoice;
      if (outcome === "accepted") {
        setIsInstalled(true);
        setInstallPrompt(null);
        window.__betterDeferredInstallPrompt = null;
        return true;
      }
    } catch {
      return false;
    }
    return false;
  }, [installPrompt]);

  const canPromptNative = Boolean(installPrompt) && !isInstalled;
  const showIOSGuideOption = isIOS && !isInstalled && !canPromptNative;

  return {
    isInstalled,
    isIOS,
    canPromptNative,
    showIOSGuideOption,
    canInstallOrGuide: canPromptNative || showIOSGuideOption,
    promptInstall,
  };
}
