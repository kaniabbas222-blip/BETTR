export type AppStage = "splash" | "onboarding" | "avatar-setup" | "main";

export type MainTab = "home" | "plan" | "notes" | "me";

export type SubView =
  | "none"
  | "money"
  | "pack"
  | "places"
  | "homecare"
  | "birthdays"
  | "gifts"
  | "automations"
  | "language";

export type PastelTone = "sage" | "sky" | "yellow" | "lavender" | "pink" | "cream";

export type TaskBucket = "today" | "tomorrow" | "week";

export type TaskCategory =
  | "school"
  | "homework"
  | "shopping"
  | "food"
  | "selfcare"
  | "errand"
  | "money"
  | "general";

export type ReminderSchedule = "once" | "daily" | "weekly" | "sunday" | "monthly" | "location";

export interface TaskItem {
  id: string;
  title: string;
  timeLabel: string;
  dateISO?: string;
  bucket: TaskBucket;
  category: TaskCategory;
  pastel: PastelTone;
  completed: boolean;
  reminder: boolean;
  reminderSchedule?: ReminderSchedule;
  locationPlaceId?: string;
  isEvent?: boolean;
  isBirthday?: boolean;
}

export type NoteKind = "note" | "checklist" | "idea" | "shopping" | "reminder" | "memory";

export interface NoteItem {
  id: string;
  title: string;
  content: string;
  kind: NoteKind;
  pastel: PastelTone;
  pinned?: boolean;
  isPrivate?: boolean;
  updatedAt: string;
}

export interface ListEntry {
  id: string;
  text: string;
  checked: boolean;
}

export interface CustomList {
  id: string;
  title: string;
  icon: "shopping" | "remember" | "selfcare" | "gift";
  pastel: PastelTone;
  items: ListEntry[];
}

export interface PackKit {
  id: string;
  title: string;
  emoji: string;
  pastel: PastelTone;
  items: ListEntry[];
}

export interface SavedPlace {
  id: string;
  name: string;
  emoji: string;
  note: string;
  reminderText: string;
  pastel: PastelTone;
}

export interface HomeCareTask {
  id: string;
  title: string;
  schedule: "Weekly" | "Every 3 days" | "Bi-weekly" | "Monthly";
  kind: "home" | "laundry";
  doneThisCycle: boolean;
  pastel: PastelTone;
}

export interface BirthdayPerson {
  id: string;
  name: string;
  dateMM_DD: string; // e.g. "11-26"
  giftIdea: string;
  notes: string;
  pastel: PastelTone;
}

export interface GiftPlan {
  id: string;
  person: string;
  gift: string;
  budget: number;
  dateLabel: string;
  status: "Idea" | "Shopping" | "Wrapped" | "Given";
  notes: string;
  pastel: PastelTone;
}

export interface PersonalThing {
  id: string;
  name: string;
  location: string;
  notes: string;
  photoDataUrl?: string;
  pastel: PastelTone;
}

export interface MemoryItem {
  id: string;
  title: string;
  note: string;
  dateISO: string;
  photoDataUrl?: string;
  isPrivate?: boolean;
  pastel: PastelTone;
}

export type MoodLevel = "great" | "good" | "okay" | "tired" | "low";

export interface MoodEntry {
  id: string;
  mood: MoodLevel;
  note: string;
  dateISO: string;
}

export interface ButterAutomation {
  id: string;
  whenLabel: string;
  doLabel: string;
  triggerType: "day" | "location" | "monthly" | "time";
  enabled: boolean;
  pastel: PastelTone;
}

export type ExpenseCategory = "Food" | "Shopping" | "Transport" | "Fun" | "Bills" | "Self-Care";

export interface ExpenseItem {
  id: string;
  amount: number;
  category: ExpenseCategory;
  note: string;
  dateISO: string;
}

export interface GoalStep {
  id: string;
  text: string;
  done: boolean;
}

export interface PersonalGoal {
  id: string;
  title: string;
  description: string;
  targetDate: string;
  steps: GoalStep[];
  manualProgress?: number;
  pastel: PastelTone;
}

export interface SavingsGoal {
  id: string;
  title: string;
  targetAmount: number;
  savedAmount: number;
  pastel: PastelTone;
}

export interface HabitItem {
  id: string;
  title: string;
  frequency: "Daily" | "3x / week" | "Weekends" | "Weekly";
  completedCountThisWeek: number;
  targetPerWeek: number;
  completedToday: boolean;
  pastel: PastelTone;
}

export type AvatarStyle = "soft" | "round" | "slender";
export type HairStyle =
  | "short"
  | "bob"
  | "wavy"
  | "buns"
  | "curly"
  | "sweep"
  | "spiky"
  | "braids";
export type TopStyle = "sweater" | "tee" | "hoodie" | "cardigan" | "overalls";
export type BottomStyle = "jeans" | "skirt" | "joggers" | "shorts";
export type DressStyle = "none" | "pinafore" | "sundress";
export type JacketStyle = "none" | "denim" | "trench" | "varsity";
export type ShoeStyle = "sneakers" | "maryjanes" | "boots" | "loafers";
export type GlassesStyle = "none" | "round" | "tortoise" | "sun";
export type HatStyle = "none" | "beanie" | "beret" | "bucket" | "bow";
export type BagStyle = "none" | "tote" | "crossbody" | "backpack";
export type HeadphoneStyle = "none" | "pastel";
export type SmallAccStyle = "none" | "blush" | "freckles" | "starpin" | "scarf";

export interface AvatarConfig {
  name: string;
  style: AvatarStyle;
  skinTone: string;
  hairStyle: HairStyle;
  hairColor: string;
  topStyle: TopStyle;
  topColor: string;
  bottomStyle: BottomStyle;
  bottomColor: string;
  dressStyle: DressStyle;
  dressColor: string;
  jacketStyle: JacketStyle;
  shoeStyle: ShoeStyle;
  glasses: GlassesStyle;
  hat: HatStyle;
  bag: BagStyle;
  headphones: HeadphoneStyle;
  smallAcc: SmallAccStyle;
}

export type RoomBackdrop = "sky" | "sage" | "butter" | "lavender" | "dusk";
export type RoomPlant = "none" | "sprout" | "monstera" | "hanging";
export type RoomFurniture = "cozy-desk" | "reading-nook" | "daybed";
export type RoomPoster = "none" | "sun" | "clouds" | "botanical";
export type RoomDecor = "none" | "fairy-lights" | "bookshelf" | "tea-set";

export interface RoomConfig {
  backdrop: RoomBackdrop;
  plant: RoomPlant;
  furniture: RoomFurniture;
  poster: RoomPoster;
  decor: RoomDecor;
  rugColor: string;
}

export type AppLanguage =
  | "en"
  | "ar"
  | "ckb"
  | "tr"
  | "es"
  | "fr"
  | "de"
  | "ko"
  | "ja"
  | "zh";

export type AppRegion =
  | "auto"
  | "IQ"
  | "US"
  | "GB"
  | "TR"
  | "ES"
  | "FR"
  | "DE"
  | "KR"
  | "JP"
  | "CN";

export type AccentColorKey = "butter" | "sage" | "sky" | "lavender" | "pink";
export type TextScale = "standard" | "large" | "xlarge";
export type HomeCardId = "weather" | "avatar" | "your-day" | "wind-down" | "mood";

export interface AppSettings {
  theme: "day" | "dusk";
  accentColor: AccentColorKey;
  language: AppLanguage;
  region: AppRegion;
  currency: "IQD" | "USD" | "EUR";
  textScale: TextScale;
  reducedMotion: boolean;
  avatarAnimations: boolean;
  morningBriefing: boolean;
  reminderChimes: boolean;
  locationPermission: "unset" | "granted" | "manual";
  manualCity: string;
  appLockEnabled: boolean;
  appLockPin: string;
  biometricEnabled: boolean;
  homeCardOrder: HomeCardId[];
  hiddenHomeCards: HomeCardId[];
  daysActive: number;
}

export interface ParsedButterItem {
  id: string;
  title: string;
  timeLabel: string;
  bucket: TaskBucket;
  destination: "plan" | "shopping" | "note" | "money" | "reminder";
  category: TaskCategory;
  reminder: boolean;
  recurrence?: ReminderSchedule;
  locationTrigger?: string;
  amount?: number;
  note?: string;
  selected: boolean;
}

export interface WeatherSnapshot {
  tempC: number;
  hiC: number;
  loC: number;
  weatherCode: number;
  condition: string;
  emoji: string;
  advice: string;
  cityLabel: string;
}
